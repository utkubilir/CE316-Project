#include <iostream>
int main() { std::cout << "Hello, CE316!\n"; return 0; }