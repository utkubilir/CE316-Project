print('Hello, CE316!')
1/0